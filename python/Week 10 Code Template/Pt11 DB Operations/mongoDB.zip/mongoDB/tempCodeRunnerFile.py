for myQuery1 in db1.find():
    pprint(myQuery1)